'''
Created on May 14, 2021

@author: User
'''
from Stack_Sort import SortingWithStack 
from Queue_Sort import SortingWithQueue
ulang = "y"
while(ulang == "y"):
    
    print("="*50)
    print("Program Sorting dengan Stack & Queue")
    print("="*50)
    print()
    print("1. Sorting dengan Stack - Descending")
    print("2. Sorting dengan Queue - Ascending")
    print()

    pilihan = int(input("Pilihan anda (1/2) :"))
    print()
    if pilihan == 1 :
        s = SortingWithStack()
        stack = s.createStack()
        n = s.inputStackLen()
        newStack = s.inputNilai(n, stack)
        
        print()
        print("Sorted Stack :")
        sortedStack = s.sortStack(newStack)
        s.printStack(sortedStack)

    elif pilihan == 2:    
        s = SortingWithQueue()
        queue = s.createQueue()
        n = s.inputQueueLen()
        newQueue = s.inputNilai(n, queue)
        
        print()
        print("Sorted Queue :")
        sortedQueue = s.sortQueue(newQueue)
        s.printQueue(sortedQueue) 
        
    else :
        print("Pilihan tidak ada!")
        print()
    
    print("="*50)
    ulang = input("Apakah anda ingin mengulang?(Y/N) : ")
    ulang = ulang.lower()
    print()
    
print("Keluar Program - Terima Kasih!")