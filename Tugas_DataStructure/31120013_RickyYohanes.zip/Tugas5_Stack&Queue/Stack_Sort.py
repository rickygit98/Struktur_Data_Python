'''
Created on May 12, 2021

@author: User
'''
# Python sorting stack - descending
# dari tinggi ke rendah

class SortingWithStack:
    def sortStack ( self,inputStack ):
        tmpStack = self.createStack()
        while(self.isEmpty(inputStack) == False):
            
            # pop elemen pertama , paling atas dari stack
            tmpItem = self.top(inputStack)
            self.pop(inputStack)
    
            # Jika tempStack memiliki isi , dan element teratas / terakhir dari temp stack
            # lebih besar dari hasil pop out input stack
            while(self.isEmpty(tmpStack) == False and self.top(tmpStack) > tmpItem):
                
                # Lakukan pop out dari tempStack dan push / "kembalikan" ke input stack
                self.push(inputStack,self.top(tmpStack))
                self.pop(tmpStack)
    
            self.push(tmpStack,tmpItem)
        
        return tmpStack
    
    
    # METHOD - METHOD Tambahan untuk melengkapi method SortStack
    # ==========================================================
    
    # 1.Menginisiasi / membuat stack baru
    def createStack(self):
        inputStack = []
        return inputStack
    
    # 2.Mengecek apakah inputStack sudah tidak memiliki item
    def isEmpty(self,inputStack):
        return len(inputStack) == 0
    
    # 3.Menambah element ke inputStack
    def push( self,inputStack, inputitem ):
        inputStack.append(inputitem)
    
    # 4.Mengambil item paling atas dari stack
    def top( self,inputStack ):
        p = len(inputStack)
        return inputStack[p-1]
    
    # 5.Menghapus / mengeluarkan item paling atas dari stack
    # Cek juga apakah stacknya masih punya element atau tidak
    def pop(self, inputStack):
        # Jika stacknya kosong , maka exit / error
        if(self.isEmpty(inputStack)):
            print("Stack Kosong ")
            exit(1)
    
        return inputStack.pop()
    
    # 6.Mencetak stack
    def printStack(self,inputStack):
        for i in range(len(inputStack)-1, -1, -1):
            print(inputStack[i], end = ' ')
        print()
    
    # 7.Minta input PanjangStack
    def inputStackLen(self):
        n = int(input('Masukkan Panjang Stack yang ingin diurutkan :'))
        return n
    
    # 8.Push nilai nilai yang diinput user
    def inputNilai(self,n,stack):
        for i in range (n) :
            x = int(input(f"Masukkan nilai ke - {i+1} : "))
            self.push(stack,x)
        return stack
