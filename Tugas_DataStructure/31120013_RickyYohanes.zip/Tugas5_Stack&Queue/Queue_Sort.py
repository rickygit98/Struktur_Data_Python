'''
Created on May 14, 2021

@author: User
'''

import collections

# Python sorting queue - ascending
# dari rendah ke tinggi

class SortingWithQueue:
    def sortQueue (self,inputQueue):
        tmpQueue = self.createQueue()
        while(self.isEmpty(inputQueue) == False):
            
            # pop elemen pertama , paling awal dari queue
            tmpItem = self.front(inputQueue)
            self.pop(inputQueue)
    
            # Jika tmpQueue memiliki isi , dan element teratas / terakhir dari tmpQueue
            # lebih besar dari hasil popout inputQueue
            while(self.isEmpty(tmpQueue) == False and self.front(tmpQueue) < tmpItem):
                
                # Lakukan pop out dari tempQueue dan push / "kembalikan" ke inputQueue
                self.push(inputQueue,self.front(tmpQueue))
                self.pop(tmpQueue)
    
            self.push(tmpQueue,tmpItem)
        
        return tmpQueue
    
    
    # METHOD - METHOD Tambahan untuk melengkapi method SortQueue
    # ==========================================================
    
    # 1.Menginisiasi / membuat Queue baru
    def createQueue(self):
        inputQueue = collections.deque([])
        return inputQueue
    
    # 2.Mengecek apakah inputQueue sudah tidak memiliki item
    def isEmpty( self,inputQueue ):
        return len(inputQueue) == 0
    
    # 3.Menambah element ke inputQueue
    def push(self, inputQueue, inputitem ):
        inputQueue.appendleft( inputitem )
    
    # 4.Mengambil item paling awal dari Queue
    def front(self,inputQueue):
        return inputQueue[0]
    
    # 5.Menghapus / mengeluarkan item paling atas dari stack
    # Cek juga apakah stacknya masih punya element atau tidak
    def pop( self,inputQueue ):
    
        # Jika Queue Kosong maka exit / error
        if(self.isEmpty(inputQueue)):
            print("Queue Kosong ")
            exit(1)
    
        return inputQueue.popleft()
    
    # 6.Mencetak Queue
    def printQueue(self,inputQueue):
        for i in range(0,len(inputQueue),1):
            print(inputQueue[i], end = ' ')
        print()
        
    # 7.Minta input PanjangQueue
    def inputQueueLen(self):
        n = int(input('Masukkan Panjang Queue yang ingin diurutkan :'))
        return n
    
    # 8.Push nilai nilai yang diinput user
    def inputNilai(self,n,queue):
        for i in range (n) :
            x = int(input(f"Masukkan nilai ke - {i+1} : "))
            self.push(queue,x)
        return queue    
