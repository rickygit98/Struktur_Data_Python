'''
Created on Jun 28, 2021

@author: User
'''
from uasjawabansoalno1 import WriteJawabanSoal1
from uasjawabansoalno2 import WriteJawabanSoal2
ulang = "y"
while(ulang == "y"):
    
    print("="*50)
    print("Program Tugas txt file Handling")
    print("="*50)
    print("1. Write Jawaban Soal nomor 1 - Umbrella Pattern")
    print("2. Write Jawaban Soal nomor 2 - Toggle Alphabet Case")
    
    print()
    
    msg_success = "Hasil output juga berhasil ditulis ke"


    pilihan = int(input("Pilihan anda (1/2) :"))
    print()
        
    if pilihan == 1 :
        jawabanSoal1 = WriteJawabanSoal1()
        n = jawabanSoal1.NilaiN();
        jawabanSoal1.WriteToConsole(n)
        myOutputFile = jawabanSoal1.OpenOutputFile()
        jawabanSoal1.WriteOutputFile(myOutputFile, n)
        jawabanSoal1.CloseOutputFile(myOutputFile)
        print()
        print(msg_success+" OutputBintang.txt")
        print()
        
    elif pilihan == 2 :
        jawabanSoal2 = WriteJawabanSoal2()
        n = jawabanSoal2.NilaiN();
        jawabanSoal2.WriteToConsole(n)
        myOutputFile = jawabanSoal2.OpenOutputFile()
        jawabanSoal2.WriteOutputFile(myOutputFile, n)
        jawabanSoal2.CloseOutputFile(myOutputFile)
        print()
        print(msg_success+" cetak.txt")   
        print()
        
    else :
        print("Pilihan tidak ada")
        print()
    
    print("="*50)
    ulang = input("Apakah anda ingin mengulang?(Y/N)")
    ulang = ulang.lower()
    print()
    
print("Keluar Program - Terima Kasih!")