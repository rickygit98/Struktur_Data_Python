'''
Created on Jun 29, 2021

@author: User
'''
class WriteJawabanSoal1:
    
    def NilaiN(self):
        n = int(input("Masukkan nilai n:"))
        return n
    
    def OpenOutputFile(self):
        myOutputFile = open("OutputBintang.txt","a")
        return myOutputFile  
    
    def WriteToConsole(self,n):
        for row in range(1,n+1):
            for col in range (1,2*n):
                if (row==n or row+col == n+1 or col-row == n-1):
                    print("*",end=" ")
                else:
                    print(" ",end=" ")
            print()

        for row in range (1,n+1):
            for col in range (1,n+1):
                if(col==n):
                    print("*",end=" ")
                else:
                    print(" ",end=" ")
            print()
             
            
    def WriteOutputFile(self,myOutputFile,n):
        myOutputFile.write(f"--- Jawaban Soal 1 Umbrella Pattern---\n")
              
        for row in range(1,n+1):
            for col in range (1,2*n):
                if (row==n or row+col == n+1 or col-row == n-1):
                    myOutputFile.write(f"* ")
                else:
                    myOutputFile.write(f"  ")
            myOutputFile.write("\n")
        
        
        for row in range (1,n+1):
            for col in range (1,n+1):
                if(col==n):
                    myOutputFile.write(f"* ")
                else:
                    myOutputFile.write(f"  ")
            myOutputFile.write("\n")
            

        
        return myOutputFile
    
    def CloseOutputFile(self,myOutputFile):
        close = myOutputFile.close()
        return close
