'''
Created on Jun 29, 2021

@author: User
'''
class WriteJawabanSoal2:
    
    def NilaiN(self):
        n = int(input("Masukkan nilai n:"))
        return n
    
    def OpenOutputFile(self):
        myOutputFile = open("cetak.txt","a")
        return myOutputFile  
    
    def WriteToConsole(self,n):
        num1 = 65
        num2 = 65
        condition = True
        
        for row in range (1,n+1):
            for col in range (1,row+1):
                char1 = chr(num1)
                char2 = chr(num2)
                if (condition == True):
                    print(char1.lower(),end=" ")
                    condition = False
                    num1 +=1
                else:
                    print(char2,end=" ")
                    condition = True
                    num2 +=1
            
            #cek nilai maksimal dari num , 69 = D
                if (num1 >=69):
                    num1 =65
                if (num2 >=69):
                    num2 =65
            print()
             
            
    def WriteOutputFile(self,myOutputFile,n):
        myOutputFile.write(f"--- Jawaban Soal 2 Toggle Alphabet Case---\n")
              
        num1 = 65
        num2 = 65
        condition = True
        
        for row in range (1,n+1):
            for col in range (1,row+1):
                char1 = chr(num1)
                char2 = chr(num2)
                if (condition == True):
                    myOutputFile.write(f"{char1.lower()} ")
                    condition = False
                    num1 +=1
                else:
                    myOutputFile.write(f"{char2} ")
                    condition = True
                    num2 +=1
            
            #cek nilai maksimal dari num , 69 = D
                if (num1 >=69):
                    num1 =65
                if (num2 >=69):
                    num2 =65
            myOutputFile.write("\n") 
            

        
        return myOutputFile
    
    def CloseOutputFile(self,myOutputFile):
        close = myOutputFile.close()
        return close
